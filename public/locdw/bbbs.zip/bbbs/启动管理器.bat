﻿@echo off
chcp 65001 >nul
title Aion2 Portal 管理器启动中...
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0manager.ps1"

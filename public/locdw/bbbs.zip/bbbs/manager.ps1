﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$BaseDir      = $PSScriptRoot
$RuntimeDir   = Join-Path $BaseDir "runtime"
$ProjectDir   = Join-Path $BaseDir "aion2-portal"
$NodeVersion  = "v22.18.0"
$PnpmVersion  = "10.29.2"
$TargetUrl    = "http://localhost:4444/"
$RepoPath     = "go2fofo/aion2-portal.git"

$GitMirrors   = @(
    "https://github.com/$RepoPath",
    "https://mirror.ghproxy.com/https://github.com/$RepoPath",
    "https://gh-proxy.com/https://github.com/$RepoPath"
)

$NodeMirrors  = @(
    "https://npmmirror.com/mirrors/node/$NodeVersion/node-$NodeVersion-win-x64.zip",
    "https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-win-x64.zip"
)

$MinGitUrl    = "https://registry.npmmirror.com/-/binary/git-for-windows/v2.47.1.windows.1/MinGit-2.47.1-64-bit.zip"

# ================= UI 界面构建 =================
$Form = New-Object System.Windows.Forms.Form
$Form.Text = "Aion2 Portal 一键部署与启动器 (Pro 终极版)"
$Form.Size = New-Object System.Drawing.Size(760, 520)
$Form.StartPosition = "CenterScreen"
$Form.FormBorderStyle = "FixedDialog"
$Form.MaximizeBox = $false
$Form.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9.5)

$LblStatus = New-Object System.Windows.Forms.Label
$LblStatus.Text = "当前状态：就绪（首次使用请点击【1. 一键安装环境】）"
$LblStatus.Location = New-Object System.Drawing.Point(20, 15)
$LblStatus.Size = New-Object System.Drawing.Size(560, 25)
$LblStatus.ForeColor = [System.Drawing.Color]::DarkBlue
$Form.Controls.Add($LblStatus)

# 附加小按钮：清空日志
$BtnClearLog = New-Object System.Windows.Forms.Button
$BtnClearLog.Text = "清空日志"
$BtnClearLog.Location = New-Object System.Drawing.Point(595, 12)
$BtnClearLog.Size = New-Object System.Drawing.Size(115, 28)
$Form.Controls.Add($BtnClearLog)

# 按钮 1：一键安装
$BtnInstall = New-Object System.Windows.Forms.Button
$BtnInstall.Text = "1. 一键安装环境"
$BtnInstall.Location = New-Object System.Drawing.Point(20, 50)
$BtnInstall.Size = New-Object System.Drawing.Size(165, 45)
$BtnInstall.BackColor = [System.Drawing.Color]::FromArgb(230, 244, 255)
$Form.Controls.Add($BtnInstall)

# 按钮 2：一键更新（全量覆盖）
$BtnUpdate = New-Object System.Windows.Forms.Button
$BtnUpdate.Text = "2. 一键更新代码"
$BtnUpdate.Location = New-Object System.Drawing.Point(195, 50)
$BtnUpdate.Size = New-Object System.Drawing.Size(165, 45)
$BtnUpdate.BackColor = [System.Drawing.Color]::FromArgb(255, 247, 230)
$Form.Controls.Add($BtnUpdate)

# 按钮 3：清理并重新编译
$BtnClean = New-Object System.Windows.Forms.Button
$BtnClean.Text = "3. 清理并重新编译"
$BtnClean.Location = New-Object System.Drawing.Point(370, 50)
$BtnClean.Size = New-Object System.Drawing.Size(165, 45)
$BtnClean.BackColor = [System.Drawing.Color]::FromArgb(255, 230, 230)
$Form.Controls.Add($BtnClean)

# 按钮 4：一键启动并打开
$BtnStart = New-Object System.Windows.Forms.Button
$BtnStart.Text = "4. 一键启动并打开"
$BtnStart.Location = New-Object System.Drawing.Point(545, 50)
$BtnStart.Size = New-Object System.Drawing.Size(165, 45)
$BtnStart.BackColor = [System.Drawing.Color]::FromArgb(230, 255, 237)
$Form.Controls.Add($BtnStart)

# 日志输出框
$TxtLog = New-Object System.Windows.Forms.TextBox
$TxtLog.Location = New-Object System.Drawing.Point(20, 110)
$TxtLog.Size = New-Object System.Drawing.Size(690, 340)
$TxtLog.Multiline = $true
$TxtLog.ScrollBars = "Vertical"
$TxtLog.ReadOnly = $true
$TxtLog.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
$TxtLog.ForeColor = [System.Drawing.Color]::FromArgb(220, 220, 220)
$TxtLog.Font = New-Object System.Drawing.Font("Consolas", 9.5)
$Form.Controls.Add($TxtLog)

# ================= 工具函数 =================
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Time = (Get-Date).ToString("HH:mm:ss")
    $TxtLog.AppendText("[$Time][$Level] $Message`r`n")
    $TxtLog.SelectionStart = $TxtLog.Text.Length
    $TxtLog.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Set-ButtonsEnabled {
    param([bool]$Enabled)
    $BtnInstall.Enabled = $Enabled
    $BtnUpdate.Enabled = $Enabled
    $BtnClean.Enabled = $Enabled
    $BtnStart.Enabled = $Enabled
    $BtnClearLog.Enabled = $Enabled
    [System.Windows.Forms.Application]::DoEvents()
}

function Show-Alert {
    param([string]$Title, [string]$Msg, [string]$Type = "Error")
    $Icon = if ($Type -eq "Error") { [System.Windows.Forms.MessageBoxIcon]::Error } else { [System.Windows.Forms.MessageBoxIcon]::Information }
    [System.Windows.Forms.MessageBox]::Show($Msg, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, $Icon) | Out-Null
}

function Inject-LocalEnv {
    $LocalNodeDir = Join-Path $RuntimeDir "node-$NodeVersion-win-x64"
    $LocalPnpmDir = Join-Path $RuntimeDir "pnpm-global"
    if (Test-Path $LocalNodeDir) {
        $env:PATH = "$LocalNodeDir;$LocalPnpmDir;$env:PATH"
        $env:PNPM_HOME = $LocalPnpmDir
    }
}

function Run-Command {
    param([string]$FilePath, [string]$Arguments, [string]$WorkDir = $BaseDir)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $WorkDir
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    $proc.Start() | Out-Null

    while (-not $proc.HasExited) {
        while (-not $proc.StandardOutput.EndOfStream) {
            $line = $proc.StandardOutput.ReadLine()
            if ($line) { Write-Log $line }
        }
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    }
    $err = $proc.StandardError.ReadToEnd()
    if ($err) { Write-Log $err "WARN" }
    return $proc.ExitCode
}

# 带有 3 次网络重试的 Git 函数
function Invoke-GitWithRetry {
    param([string]$Arguments, [string]$WorkDir = $BaseDir, [int]$MaxRetries = 3)
    $attempt = 1
    while ($attempt -le $MaxRetries) {
        Write-Log "执行 Git 操作 (第 $attempt/$MaxRetries 次尝试): git $Arguments"
        $code = Run-Command -FilePath "git" -Arguments $Arguments -WorkDir $WorkDir
        if ($code -eq 0) { return 0 }
        Write-Log "第 $attempt 次尝试失败，网络波动，等待 2 秒后自动重试..." "WARN"
        Start-Sleep -Seconds 2
        $attempt++
    }
    return -1
}

# 智能清理残留的同项目 Node 僵尸进程
function Clear-StaleNodeProcesses {
    try {
        $staleProcs = Get-WmiObject Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*aion2-portal*" }
        foreach ($p in $staleProcs) {
            Write-Log "清理残留的旧服务进程 (PID: $($p.ProcessId))..."
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}

# 检查并处理 .env 配置文件
function Check-AndInitEnvFile {
    $EnvPath = Join-Path $ProjectDir ".env"
    $EnvExamplePath = Join-Path $ProjectDir ".env.example"
    
    if (-not (Test-Path $EnvPath)) {
        if (Test-Path $EnvExamplePath) {
            Copy-Item $EnvExamplePath $EnvPath -Force
            Write-Log "检测到缺少 .env 文件，已自动由 .env.example 模板生成！" "WARN"
            Show-Alert "提示" "已自动为您创建 .env 配置文件！" "Information"
        } else {
            $DefaultEnv = "SUPABASE_URL=your_supabase_url`nSUPABASE_KEY=your_supabase_key`nNUXT_PUBLIC_SUPABASE_URL=your_supabase_url`nNUXT_PUBLIC_SUPABASE_KEY=your_supabase_key"
            Set-Content -Path $EnvPath -Value $DefaultEnv -Encoding utf8
            Write-Log "已自动初始化默认 .env 模板文件。" "WARN"
        }
    } else {
        Write-Log "检测到 .env 配置文件已就绪。"
    }
}

# ================= 优化功能：清空日志按钮 =================
$BtnClearLog.Add_Click({
    $TxtLog.Clear()
    Write-Log "日志已清空。"
})

# ================= 确保便携版 Git =================
function Ensure-Git {
    if (Get-Command "git" -ErrorAction SilentlyContinue) {
        Write-Log "检测到系统已安装 Git。"
        return $true
    }
    $MinGitExe = Join-Path $RuntimeDir "mingit\cmd\git.exe"
    if (Test-Path $MinGitExe) {
        $env:PATH = "$(Join-Path $RuntimeDir 'mingit\cmd');$env:PATH"
        Write-Log "已加载内置便携版 Git。"
        return $true
    }

    Write-Log "未检测到 Git，正在准备获取便携版 MinGit..."
    New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
    $MinGitZip = Join-Path $RuntimeDir "mingit.zip"
    
    if (Test-Path $MinGitZip) {
        Write-Log "发现本地已存在 mingit.zip 缓存，直接进行离线解压..."
    } else {
        try {
            Write-Log "正在下载 MinGit..."
            Invoke-WebRequest -Uri $MinGitUrl -OutFile $MinGitZip -UseBasicParsing -TimeoutSec 60
        } catch {
            Show-Alert "Git 下载失败" "当前电脑未安装 Git，且自动下载便携版失败。"
            return $false
        }
    }

    try {
        Expand-Archive -Path $MinGitZip -DestinationPath (Join-Path $RuntimeDir "mingit") -Force
        $env:PATH = "$(Join-Path $RuntimeDir 'mingit\cmd');$env:PATH"
        Write-Log "便携版 Git 配置完成！"
        return $true
    } catch {
        Show-Alert "Git 解压失败" "MinGit 压缩包解压出错。"
        return $false
    }
}

# ================= 确保独立 Node 与 pnpm（含离线缓存） =================
function Ensure-NodeAndPnpm {
    Inject-LocalEnv
    $LocalNodeDir = Join-Path $RuntimeDir "node-$NodeVersion-win-x64"
    $NodeExe = Join-Path $LocalNodeDir "node.exe"

    $NeedNode = $true
    if (Test-Path $NodeExe) {
        $curVer = & $NodeExe -v
        if ($curVer -eq $NodeVersion) {
            Write-Log "Node $NodeVersion 已就绪。"
            $NeedNode = $false
        }
    }

    if ($NeedNode) {
        Write-Log "正在准备独立 Node $NodeVersion 环境..."
        New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
        $NodeZip = Join-Path $RuntimeDir "node.zip"
        
        if (Test-Path $NodeZip) {
            Write-Log "发现本地已存在 node.zip 缓存，直接进行离线解压..."
        } else {
            $Downloaded = $false
            foreach ($url in $NodeMirrors) {
                try {
                    Write-Log "尝试下载：$url"
                    Invoke-WebRequest -Uri $url -OutFile $NodeZip -UseBasicParsing -TimeoutSec 120
                    $Downloaded = $true
                    break
                } catch {
                    Write-Log "该节点下载超时或失败，切换下一个..." "WARN"
                }
            }
            if (-not $Downloaded) {
                Show-Alert "Node 环境下载失败" "无法下载 Node $NodeVersion。"
                return $false
            }
        }

        Write-Log "正在解压 Node 环境..."
        Expand-Archive -Path $NodeZip -DestinationPath $RuntimeDir -Force
        Inject-LocalEnv
        Write-Log "Node $NodeVersion 安装完成！"
    }

    $PnpmCmd = Join-Path $LocalNodeDir "pnpm.cmd"
    $NeedPnpm = $true
    if (Test-Path $PnpmCmd) {
        $pVer = & $PnpmCmd -v
        if ($pVer -eq $PnpmVersion) {
            Write-Log "pnpm $PnpmVersion 已就绪。"
            $NeedPnpm = $false
        }
    }

    if ($NeedPnpm) {
        Write-Log "正在安装 pnpm@$PnpmVersion ..."
        & (Join-Path $LocalNodeDir "npm.cmd") config set registry https://registry.npmmirror.com | Out-Null
        $code = Run-Command -FilePath (Join-Path $LocalNodeDir "npm.cmd") -Arguments "install -g pnpm@$PnpmVersion --registry=https://registry.npmmirror.com"
        if ($code -ne 0) {
            Show-Alert "pnpm 安装失败" "安装 pnpm@$PnpmVersion 失败。"
            return $false
        }
        & $PnpmCmd config set registry https://registry.npmmirror.com | Out-Null
        Write-Log "pnpm $PnpmVersion 安装完成！"
    }

    return $true
}

function Setup-Npmrc {
    $NpmrcPath = Join-Path $ProjectDir ".npmrc"
    $NpmrcContent = "shamefully-hoist=true"
    Set-Content -Path $NpmrcPath -Value $NpmrcContent -Encoding utf8
    Write-Log "已自动配置 pnpm 依赖提升 (.npmrc)。"
}

# ================= 按钮 1：一键安装 =================
$BtnInstall.Add_Click({
    Set-ButtonsEnabled $false
    $LblStatus.Text = "当前状态：正在检查并安装环境与代码..."

    if (-not (Ensure-Git)) { Set-ButtonsEnabled $true; return }
    if (-not (Ensure-NodeAndPnpm)) { Set-ButtonsEnabled $true; return }

    if (Test-Path (Join-Path $ProjectDir ".git")) {
        Write-Log "检测到项目目录已存在，跳过重复克隆。"
    } else {
        if (Test-Path $ProjectDir) { Remove-Item $ProjectDir -Recurse -Force }
        $Cloned = $false
        foreach ($mirror in $GitMirrors) {
            Write-Log "正在尝试拉取代码：$mirror"
            $code = Invoke-GitWithRetry -Arguments "clone --depth 1 $mirror `"$ProjectDir`""
            if ($code -eq 0) {
                $Cloned = $true
                break
            }
            Write-Log "当前镜像多次尝试均失败，切换加速镜像..." "WARN"
            if (Test-Path $ProjectDir) { Remove-Item $ProjectDir -Recurse -Force }
        }

        if (-not $Cloned) {
            Show-Alert "GitHub 访问失败" "所有 GitHub 节点及重试均无法连接！请检查网络或开启代理。"
            $LblStatus.Text = "当前状态：安装失败"
            Set-ButtonsEnabled $true
            return
        }
        Write-Log "代码下载成功！"
    }

    Setup-Npmrc
    Check-AndInitEnvFile

    Write-Log "正在安装项目依赖 (pnpm install)..."
    $code = Run-Command -FilePath "pnpm.cmd" -Arguments "install" -WorkDir $ProjectDir
    if ($code -ne 0) {
        Show-Alert "依赖安装失败" "pnpm install 执行失败。"
        $LblStatus.Text = "当前状态：依赖安装失败"
        Set-ButtonsEnabled $true
        return
    }

    $LblStatus.Text = "当前状态：全部安装完成！请点击【4. 一键启动并打开】"
    Write-Log "=== 恭喜！所有环境与项目依赖均已安装完成 ==="
    Show-Alert "安装成功" "环境、代码与依赖已全部安装完毕！" "Info"
    Set-ButtonsEnabled $true
})

# ================= 按钮 2：一键更新（全量覆盖 + 3次重试） =================
$BtnUpdate.Add_Click({
    if (-not (Test-Path (Join-Path $ProjectDir ".git"))) {
        Show-Alert "未找到项目" "尚未安装项目代码，请先点击【1. 一键安装环境】！"
        return
    }

    Set-ButtonsEnabled $false
    $LblStatus.Text = "当前状态：正在强制全量更新代码（自动重试中）..."
    Inject-LocalEnv
    Ensure-Git | Out-Null

    Write-Log "正在从远程仓库强行同步最新代码..."
    $code = Invoke-GitWithRetry -Arguments "fetch --all" -WorkDir $ProjectDir
    
    if ($code -eq 0) {
        $code = Invoke-GitWithRetry -Arguments "reset --hard origin/main" -WorkDir $ProjectDir
        if ($code -ne 0) {
            $code = Invoke-GitWithRetry -Arguments "reset --hard origin/master" -WorkDir $ProjectDir
        }
    }

    if ($code -eq 0) {
        Write-Log "正在清理本地冗余与未跟踪文件 (git clean -fd)..."
        Run-Command -FilePath "git" -Arguments "clean -fd" -WorkDir $ProjectDir | Out-Null
    }

    if ($code -ne 0) {
        Show-Alert "更新失败" "连续重试 3 次后仍无法连接到 GitHub 拉取更新！"
        $LblStatus.Text = "当前状态：代码更新失败"
        Set-ButtonsEnabled $true
        return
    }

    Setup-Npmrc
    Check-AndInitEnvFile

    Write-Log "正在重新安装与对齐依赖 (pnpm install)..."
    Run-Command -FilePath "pnpm.cmd" -Arguments "install" -WorkDir $ProjectDir | Out-Null
    Show-Alert "更新成功" "代码已强制全量覆盖，依赖已同步至最新！" "Info"
    $LblStatus.Text = "当前状态：代码全量更新完成"
    Set-ButtonsEnabled $true
})

# ================= 按钮 3：清理并重新编译 =================
$BtnClean.Add_Click({
    if (-not (Test-Path (Join-Path $ProjectDir "package.json"))) {
        Show-Alert "未找到项目" "尚未安装项目，请先完成安装！"
        return
    }

    Set-ButtonsEnabled $false
    $LblStatus.Text = "当前状态：正在清理缓存并准备重新编译..."
    Write-Log "=== 开始清理项目缓存与编译目录 ==="

    $NuxtDir = Join-Path $ProjectDir ".nuxt"
    $OutputDir = Join-Path $ProjectDir ".output"
    $CacheDir = Join-Path $ProjectDir "node_modules\.cache"

    if (Test-Path $NuxtDir) {
        Remove-Item $NuxtDir -Recurse -Force
        Write-Log "已清理旧的 .nuxt 编译缓存。"
    }
    if (Test-Path $OutputDir) {
        Remove-Item $OutputDir -Recurse -Force
        Write-Log "已清理旧的 .output 构建产物。"
    }
    if (Test-Path $CacheDir) {
        Remove-Item $CacheDir -Recurse -Force
        Write-Log "已清理 node_modules 缓存。"
    }

    Write-Log "正在重新安装与对齐依赖..."
    Inject-LocalEnv
    Setup-Npmrc
    Check-AndInitEnvFile
    Run-Command -FilePath "pnpm.cmd" -Arguments "install" -WorkDir $ProjectDir | Out-Null

    Write-Log "=== 清理与重置完成！请点击【4. 一键启动并打开】开始全新编译 ==="
    Show-Alert "清理完成" "缓存已清空，依赖已重置！`n现在可以点击【4. 一键启动并打开】进行全新编译了。" "Info"
    $LblStatus.Text = "当前状态：清理完成，请点击【4. 一键启动并打开】"
    Set-ButtonsEnabled $true
})

# ================= 按钮 4：一键打开（已改为 pnpm run dev:nosupabase） =================
$BtnStart.Add_Click({
    if (-not (Test-Path (Join-Path $ProjectDir "package.json"))) {
        Show-Alert "未安装项目" "未检测到项目文件，请先点击【1. 一键安装环境】！"
        return
    }

    Set-ButtonsEnabled $false
    Inject-LocalEnv
    
    # 启动前智能清理旧的僵尸 Node 进程，防止端口被死锁占用
    Clear-StaleNodeProcesses

    $LblStatus.Text = "当前状态：正在启动服务，请稍候..."
    Write-Log "正在后台启动服务 (pnpm run dev:nosupabase)..."

    $PortInUse = Get-NetTCPConnection -LocalPort 4444 -State Listen -ErrorAction SilentlyContinue
    if ($PortInUse) {
        Write-Log "检测到 4444 端口已在运行, 直接为您打开浏览器..."
        Start-Process $TargetUrl
        Show-Alert "服务已在运行" "检测到服务已在后台运行, 已为您打开浏览器：$TargetUrl" "Info"
        $LblStatus.Text = "当前状态：服务运行中 ($TargetUrl)"
        Set-ButtonsEnabled $true
        return
    }

    $StartCmd = "/c title Aion2-Portal-Server && pnpm run dev:nosupabase"
    Start-Process -FilePath "cmd.exe" -ArgumentList $StartCmd -WorkingDirectory $ProjectDir -WindowStyle Normal

    $Ready = $false
    for ($i = 1; $i -le 40; $i++) {
        Start-Sleep -Seconds 1
        [System.Windows.Forms.Application]::DoEvents()
        $Check = Get-NetTCPConnection -LocalPort 4444 -State Listen -ErrorAction SilentlyContinue
        if ($Check) {
            $Ready = $true
            break
        }
        if ($i % 5 -eq 0) { Write-Log "正在等待服务编译并监听 4444 端口 ($i/40秒)..." }
    }

    if ($Ready) {
        Write-Log "服务启动成功！正在打开浏览器：$TargetUrl"
        $LblStatus.Text = "当前状态：运行中 ($TargetUrl)"
        Start-Process $TargetUrl
        Show-Alert "启动成功" "服务已成功启动！`n已自动在浏览器中打开：$TargetUrl" "Info"
    } else {
        Write-Log "等待端口 4444 超时。" "ERROR"
        $LblStatus.Text = "当前状态：启动超时，请检查日志"
        Show-Alert "启动超时" "40秒内未检测到 4444 端口就绪。"
    }

    Set-ButtonsEnabled $true
})

$Form.Add_Shown({
    Write-Log "欢迎使用 Aion2 Portal 终极版管理器。"
    if ((Test-Path (Join-Path $ProjectDir "package.json")) -and (Test-Path (Join-Path $RuntimeDir "node-$NodeVersion-win-x64\node.exe"))) {
        $LblStatus.Text = "当前状态：环境与项目已就绪，可直接点击【4. 一键启动并打开】"
        Write-Log "检测到本地已完成安装，可直接启动。"
    } else {
        Write-Log "首次运行，请点击上方【1. 一键安装环境】按钮开始自动部署。"
    }
})

[void]$Form.ShowDialog()
